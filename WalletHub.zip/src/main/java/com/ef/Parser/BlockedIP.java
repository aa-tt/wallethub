package com.ef.Parser;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BlockedIP {
	
	String ip;
	Integer hitCount;

}
